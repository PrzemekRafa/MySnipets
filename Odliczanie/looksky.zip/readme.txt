
  Thank you for downloading the 
  LOOKSKY FONT

  Don't worry, it ain't cost a thing, 
  because it is a freeware!

  This is my 1st font, but 
  check out www.unbornchikken.com 
  for new fonts by me!




  Espen Kvalheim ( aka <the:m.> ),
  MondayRec Media

  Copyright December 4, 2001



